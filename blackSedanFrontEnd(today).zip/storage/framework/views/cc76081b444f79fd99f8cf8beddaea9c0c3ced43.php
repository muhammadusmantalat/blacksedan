<?php $__env->startSection('title', 'index'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .form_content_page .input_style {
            width: 100%;
            box-sizing: border-box;
            margin-bottom: 5px;
            border: none;
            background: none;
            border-bottom: 2px solid white;
        }

        .form_content_page thead td {
            font-weight: 700;
        }
    </style>
    <!-- #pagetitle -->
    <div id="pagetitle" class="page-title bg-image">
        <div class="container">
            <div class="page-title-inner">
                <div class="page-title-holder">
                    <h1 class="page-title">Reservation Form</h1>
                </div>
                <ul class="ct-breadcrumb">
                    <li><a class="breadcrumb-entry" href="https://blacksedans.ca/">Black Sedan Limousine
                            Services</a></li>
                    <li><span class="breadcrumb-entry">Reservation Form</span></li>

                </ul>
            </div>
        </div>
    </div>
    <div id="content" class="site-content form_content_page">
        <div class="container">
            <form action="<?php echo e(route('confirmBooking')); ?>" method="POST" id="myForm">
                <input type="hidden" name="payment_option" id="payment_option" value="">
                <?php if($tripType == 'one_way'): ?>
                    <div id="primary">
                        <div class="elementor-container elementor-column-gap-default">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12 reserv-form">
                                <div class="elementor-widget-container ">
                                    <div class="ct-pricing-layout3" data-wow-delay="ms"
                                        style="background-color: #000; margin: 50px 0;">
                                        <div class="pricing-meta">
                                            <h3 class="pricing-title">Subtotal</h3>
                                        </div>
                                        <div class="pricing-price">CAD <?php echo e(number_format($totalAmount, 2, '.', '')); ?><span></span>
                                        </div>
                                        <div class="small text-white my-3 px-3 text-center">
                                            <p class="mb-0"><strong>Tax and Gratuity Included!</strong></p>
                                            <p>Please Note: 5% GST and 15% Gratuity have been added to the total cost. Any additional charged will be applied at an hourly rate plus GST and Gratuity.</p>
                                        </div>
                                        
                                        <div class="pricing-holder">
                                            <ul class="pricing-feature">
                                                <li class=""><i class="fac fac-check"></i><strong>Distance:</strong>
                                                    <?php echo e(round($distance, 2)); ?> km</li>
                                                <li class=""><i class="fac fac-check"></i><strong>Airport
                                                        Pick-up:</strong>
                                                    <?php echo e(strtoupper($airPortpickup)); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Base Price:</strong>
                                                    CAD <?php echo e(number_format($basePrice, 2, '.', '')); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Airport
                                                        Charges:</strong>
                                                    CAD <?php echo e(number_format($airPortCharges ?? 0, 2, '.', '')); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Trip Type:</strong>
                                                    <?php if($tripType == 'one_way'): ?>
                                                        One Way Trip
                                                    <?php endif; ?>
                                                </li>
                                               <?php if(!empty(session('bookingData.flight_number'))): ?>
                                                    <li class=""><i class="fac fac-check"></i><strong>Flight Number:</strong>
                                                        <?php echo e(session('bookingData.flight_number')); ?>

                                                    </li>
                                                <?php endif; ?>

                                                <li class=""><i class="fac fac-check"></i><strong>Pick-up:</strong>
                                                    <?php echo e($pickupLocation); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Drop-off:</strong>
                                                    <?php echo e($dropoffLocation); ?></li>
                                            </ul>
                                            <p style="color:#fff; font-size: 12px;"><strong>Note:</strong> Payment will be
                                                charged 24 hours before the trip.</p>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <button type="submit" class="cwcc-button" style="width: 100%;"
                                                        onclick="setPaymentOption('no_card')">Confirm Without Credit
                                                        Card</button>
                                                </div>
                                                <div class="col-md-6">
                                                    <button type="submit" class="cwthcc-button" style="width: 100%;"
                                                        onclick="setPaymentOption('with_card')">Confirm With Credit
                                                        Card</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div id="primary" class="col-12">
                        <div class="elementor-container elementor-column-gap-default">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12 reserv-form">
                                <div class="elementor-widget-container ">
                                    <div class="ct-pricing-layout3" data-wow-delay="ms"
                                        style="background-color: #000; margin: 50px 0;">
                                        <div class="pricing-meta">
                                            <h3 class="pricing-title">Subtotal</h3>
                                        </div>
                                        <div class="pricing-price">
                                            CAD <?php echo e(number_format($totalAmount, 2, '.', '')); ?><span></span>
                                        </div>
                                        <?php if($tripType == 'by_hour'): ?>
                                            <div class="small text-white my-3 px-3 text-center">
                                                <p class="mb-0"><strong>Tax and Gratuity Included!</strong></p>
                                                <p>Please Note: 5% GST and 15% Gratuity have been added to the total cost. Any additional charged will be applied at an hourly rate plus GST and Gratuity.</p>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-white my-3 px-3 text-center">
                                                <p class="mb-0"><strong>Tax and Gratuity Included!</strong></p>
                                                <p>Please Note: 5% GST and 15% Gratuity have been added to the total cost. Any additional charged will be applied at an hourly rate plus GST and Gratuity.</p>
                                            </div>
                                        <?php endif; ?>
                                        <div class="pricing-holder">
                                            <ul class="pricing-feature">
                                                <li class=""><i class="fac fac-check"></i><strong>Airport
                                                        Pick-up:</strong>
                                                    <?php echo e(strtoupper($airPortpickup)); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Base Price:</strong>
                                                    CAD <?php echo e(number_format($basePrice, 2, '.', '')); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Airport
                                                        Charges:</strong>
                                                    CAD <?php echo e(number_format($airPortCharges ?? 0, 2, '.', '')); ?>

                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Trip Type:</strong>
                                                    <?php if($tripType == 'by_hour'): ?>
                                                        By Hours Trip
                                                    <?php endif; ?>
                                                </li>
                                                <li class=""><i class="fac fac-check"></i><strong>Hours
                                                        Duration:</strong>
                                                    <?php echo e($hoursDuration); ?>

                                                </li>
                                               <?php if(!empty(session('bookingData.flight_number'))): ?>
                                                    <li class=""><i class="fac fac-check"></i><strong>Flight Number:</strong>
                                                        <?php echo e(session('bookingData.flight_number')); ?>

                                                    </li>
                                                <?php endif; ?>

                                                <li class=""><i class="fac fac-check"></i><strong>Pick-up:</strong>
                                                    <?php echo e($pickupLocation); ?>

                                                </li>

                                            </ul>
                                            <p style="color:#fff; font-size: 12px;"><strong>Note:</strong> Payment will be
                                                charged 24 hours before the trip.</p>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <button type="submit" class="cwcc-button" style="width: 100%;"
                                                        onclick="setPaymentOption('no_card')">Confirm Without Credit
                                                        Card</button>
                                                </div>
                                                <div class="col-md-6">
                                                    <button type="submit" class="cwthcc-button" style="width: 100%;"
                                                        onclick="setPaymentOption('with_card')">Confirm With Credit
                                                        Card</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script>
        function setPaymentOption(option) {
            document.getElementById('payment_option').value = option;
        }
        $(document).ready(function() {
            $('.checkoption').click(function() {
                $('.checkoption').not(this).prop('checked', false);
            });
        });
        document.getElementById('myForm').addEventListener('submit', function(event) {
            var creditCardInput = document.getElementById('creditCard');
            var creditCardValue = creditCardInput.value;

            var regex = /^[\d]{4}-[\d]{4}-[\d]{4}-[\d]{4}$/;

            if (!regex.test(creditCardValue)) {
                alert('Invalid credit card format. Please use the format XXXXXXXXXXXXXXXX');
                event.preventDefault(); // Prevent form submission
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blackSedanFrontEnd\resources\views/frontend/creditCard.blade.php ENDPATH**/ ?>