<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html"> <img alt="image"
                    src="<?php echo e(asset('public/admin/assets/images/2020-10-Black_Sedan_logo.png')); ?>" class="header-logo" />
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/dashboard')); ?>" class="nav-link <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>"><i
                        class="fas fa-th-large"></i><span>Dashboard</span></a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/requests*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('chauffer.requests')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/requests*') ? 'active' : ''); ?>"><i
                        class="fas fa-calendar-check"></i><span>Chauffer Account Requests</span>
                        <div id="requestCounter"
                            class="badge <?php echo e(request()->is('admin/requests*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/chauffer*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('chauffer.index')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/chauffer*') ? 'active' : ''); ?>"><i
                        class="fas fa-calendar-check"></i><span>Chauffers</span></a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/customer*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('customer.index')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/customers*') ? 'active' : ''); ?>"><i
                        class="fas fa-calendar-check"></i><span>Customers</span></a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/getBooking*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('getBooking')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/getBooking*') ? 'active' : ''); ?>"><i
                        class="fas fa-calendar-check"></i><span>Offers</span>
                        <div id="offersCounter"
                            class="badge <?php echo e(request()->is('admin/getBooking*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/getUpcomingRides*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('getUpcomingRides')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/getUpcomingRides*') ? 'active' : ''); ?>"><i
                        class="fas fa-clock"></i><span>Upcoming rides</span>
                        <div id="upComingRidesCounter"
                            class="badge <?php echo e(request()->is('admin/getUpcomingRides*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/getPastRides*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('getPastRides')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/getPastRides*') ? 'active' : ''); ?>"><i
                        class="fas fa-history"></i><span>Past Rides</span>
                        <div id="pastRidesCounter"
                            class="badge <?php echo e(request()->is('admin/getPastRides*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
            </li>
            
            <li class="dropdown <?php echo e(request()->is('admin/vehicle*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('vehicle.index')); ?>" class="nav-link  <?php echo e(request()->is('admin/vehicle*') ? 'active' : ''); ?>"><i class='fas fa-car'
                        style='font-size:24px'></i></i><span>Vehicle</span></a>
            </li>

            <li class="dropdown <?php echo e(request()->is('admin/delete*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('delete.requests.index')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/delete*') ? 'active' : ''); ?>"><i
                        class="fas fa-history"></i><span>Delete Account Requests</span>
                        <div id="deleteRequestCounter"
                            class="badge <?php echo e(request()->is('admin/delete*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
            </li>
            
        </ul>
    </aside>
</div>

<?php /**PATH C:\xampp\htdocs\blackSedanFrontEnd\resources\views/admin/common/side_menu.blade.php ENDPATH**/ ?>