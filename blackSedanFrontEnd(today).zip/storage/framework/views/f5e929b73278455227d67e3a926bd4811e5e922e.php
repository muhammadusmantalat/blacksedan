<div class="modal-content">
    <div class="modal-header justify-content-center">
        <h5 class="modal-title">Booking Details</h5>
    </div>
    <div class="modal-body">
        <div class="container table-responsive">
            <table class="table table-bordered table-hover">
                <tbody>
                    <tr>
                        <th scope="col">Service Type</th>
                        <td><?php echo e($booking->vehicle->name); ?></td>
                    </tr>

                    <tr>
                        <th scope="col">Trip Type</th>
                        <td>
                            <?php if($booking->trip_type == 'by_hour'): ?>
                                <span>By Hour</span>
                            <?php else: ?>
                                <span>One Way</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="col">Airport Charges</th>
                        <td>
                            <?php if($booking->air_port_charges > 0): ?>
                                <span>$<?php echo e($booking->air_port_charges); ?></span>
                            <?php else: ?>
                                <span>No Charges Found!</span>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <th scope="col">Duration</th>
                        <td>
                            <?php if($booking->duration_hours > 0): ?>
                                <span><?php echo e($booking->duration_hours); ?> hours</span>
                            <?php else: ?>
                                <span>No Duration Found!</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="col">Airport PickUp</th>
                        <td>
                            <?php if($booking->airport_pickup == 'yes'): ?>
                                <span>Yes</span>
                            <?php else: ?>
                                <span>No</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="col">First Name</th>
                        <td><?php echo e($booking->first_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Last Name</th>
                        <td><?php echo e($booking->last_name); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Email</th>
                        <td><?php echo e($booking->email); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Phone Number</th>
                        <td><?php echo e($booking->phone_number); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Instructions</th>
                        <td><?php echo e($booking->instruction); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Pickup Date</th>
                        <td><?php echo e($booking->pickup_date); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Pickup Time</th>
                        <td><?php echo e(\Carbon\Carbon::parse($booking->pickup_time)->format('h:i A')); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Pickup Location</th>
                        <td><?php echo e($booking->pickup_location); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">DropOff Location</th>
                        <td><?php echo e($booking->dropOff_location ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Cardholder Name</th>
                        <td><?php echo e($booking->card_holder_number ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Card No</th>
                        <td><?php echo e($booking->card_number ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Expire Month</th>
                        <td><?php echo e($booking->exp_month ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Expire Year</th>
                        <td><?php echo e($booking->exp_year ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">CVV</th>
                        <td><?php echo e($booking->cvv ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Card Type</th>
                        <td><?php echo e($booking->card_type ?? 'No Data Found!'); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Distance</th>
                        <td>
                            <?php if($booking->distance == null): ?>
                                <span>No Data Found!</span>
                            <?php else: ?>
                                <?php echo e($booking->distance); ?> km
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="col">Total Amount</th>
                        <td>$<?php echo e($booking->total_amount); ?></td>
                    </tr>
                    <tr>
                        <th scope="col">Destination</th>
                        <td>
                            <?php if($booking->destination == null): ?>
                                <span>No Data Found!</span>
                            <?php else: ?>
                                <?php echo e($booking->destination); ?> km
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="col">Reason For Cancellation</th>
                        <td>
                            <?php if($booking->reason): ?>
                                <p><?php echo e($booking->reason); ?></p>
                            <?php else: ?>
                                <span class="text-danger">No Reason Found!</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="modal-footer justify-content-center">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\blackSedanFrontEnd\resources\views/admin/bookings/model.blade.php ENDPATH**/ ?>