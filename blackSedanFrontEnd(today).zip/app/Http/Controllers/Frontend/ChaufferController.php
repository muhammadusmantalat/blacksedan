<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Booking;
use App\Models\Chauffer;
use App\Models\Vehicle;
use App\Models\Vehicledetail;
use App\Mail\RegistrationMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class ChaufferController extends Controller
{
    public function getLoginPage(){
        return view('frontend.chauffeur-sign-in');
    }

    public function getChaufferAccount(){
        $user = Auth::guard('chauffeur')->user();
        $userVehicle = Vehicledetail::where('chauffers_id',$user->id)->first();
        $vehicles =  Vehicle::latest()->get();
        // return $vehicle;
        return view('frontend.chauffeur-account', compact('user','userVehicle','vehicles'));
    }

    public function chaufferData(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'fname' => 'required|string|max:255',
            'lname' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|string|max:20',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
    
        $user = User::create([
            'fname'  => $request->fname,
            'lname'  => $request->lname,
            'email'  => $request->email,
            'phone'  => $request->phone,
            'status' => 'requested',
            'type'   => 'chauffer',
        ]);
    
        return response()->json([
            'status'  => 'success',
            'message' => 'Data sent to admin successfully.'
        ]);
    }
    

    public function Chauffersigup(Request $request) {
        try {
            $validator = Validator::make($request->all(), [
                'full_name' => 'required|string|max:255',
                'last_name' => 'required|string|max:255',
                'email'    => 'required|email|unique:chauffers,email',
                'phone'     => 'required|string|max:20',
                'password'  => 'required|min:6',
            ]);
    
            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }
    
            // Create or update the chauffeur user in the new table
            $user = Chauffer::create([
                'email'    => $request->email,
                'fname'    => $request->full_name,
                'lname'    => $request->last_name,
                'phone'    => $request->phone,
                'password' => bcrypt($request->password),
            ]);
            $data['name'] = $user->name;
            Mail::to($user->email)->send(new RegistrationMail($data));
            return response()->json([
                'message'  => $user->wasRecentlyCreated ? 'Registration successful!' : 'User updated successfully!',
                'user'     => $user,
                // 'redirect' => route('chauffeur.login')
            ], 200);
    
        } catch (\Exception $e) {
            return response()->json(['error' => 'Something went wrong!', 'details' => $e->getMessage()], 500);
        }
    }
    

    public function chauffeurLogin(Request $request) {
        try {
            $validator = Validator::make($request->all(), [
                'email'    => 'required|email',
                'password' => 'required|min:6',
            ]);
    
            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }
    
            // Chauffeur model se user fetch karen
            $user = Chauffer::where('email', $request->email)->first();
            // return $user;
    
            // Agar user na mile ya password match na kare
            // if (!$user || !Hash::check($request->password, $user->password)) {
            //     return response()->json(['message' => 'Invalid credentials.'], 401);
            // }
            if (!auth()->guard('chauffeur')->attempt(['email' => $request->email, 'password' => $request->password])) {
                return back()->with('message', 'Invalid email or password');
            }
            // return "k";
            // Agar login successful ho to success message return karein
            return response()->json(['message' => 'Login successful!'], 200);
    
        } catch (\Exception $e) {
            return response()->json(['error' => 'Something went wrong!', 'details' => $e->getMessage()], 500);
        }
    }
    
    // Email validation for checking duplicate emails
    public function chaufferEmail(Request $request) {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'type'  => 'required|in:chauffer,customer',
        ]);
        
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        
        $existingUser = Chauffer::where('email', $request->email)->first();
        
        if ($existingUser) {
            // Email exists; check if type matches
            if ($existingUser->type !== $request->type) {
                return response()->json([
                    'duplicate' => true, 
                    'message' => 'This email is already registered.'
                ], 400);
            }
            // Allow if same type (e.g., updating existing chauffeur)
            return response()->json(['duplicate' => true, 'message' => 'Email already in use.'], 200);
        }
        
        return response()->json(['duplicate' => false, 'message' => 'Email is available.'], 200);
    }

    public function chauffeurRides() {
        $completeBookings = Booking::where('chauffer_id',Auth::guard('chauffeur')->user()->id)->where('status','Completed')->latest()->get();
        $upComingBookings = Booking::where('chauffer_id',Auth::guard('chauffeur')->user()->id)->where('status','Accepted')->latest()->get();
        $offers = Booking::where('chauffer_id',Auth::guard('chauffeur')->user()->id)->where('status','Booked')->latest()->get();
        $cancleBookings = Booking::where('chauffer_id',Auth::guard('chauffeur')->user()->id)->whereIn('status',['cancelled','Completed'])->latest()->get();
        $vehicles = Vehicle::latest()->get();
        return view('frontend.chauffeur-rides',compact('vehicles','offers','completeBookings','upComingBookings','cancleBookings'));
    }
    public function chauffeurRidesAccept(Request $request) {
        $id = $request->bookingId;
        $data = Booking::find($id);
    
        if ($data) {
            $data->status = 'Accepted';
            $data->save();
    
            return response()->json([
                'status' => 'success',
                'message' => 'Offer Accepted Successfully',
            ]);
        } else {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found',
            ], 404);
        }
    }
    public function chauffeurRidesStatus(Request $request) {
        $id = $request->btnId;
        $data = Booking::find($id);
    
        if ($data) {
            $data->chauffeurs_response = $request->status;
            if ($request->status == '2') {
                $data->status = 'Completed';
            }
            $data->save();
            return response()->json([
                'status' => 'success',
                'message' => 'Status Successfully',
            ]);
        } else {
            return response()->json([
                'status' => 'error',
                'message' => 'Booking not found',
            ], 404);
        }
    }
    public function updateChauffeur(Request $request) {
        try {
            $validator = Validator::make($request->all(), [

                'fname'     => 'string|max:255',
                'lname'     => 'string|max:255',
                'phone'     => 'string|max:20',
                'password'  => 'nullable|min:6',
            ]);
    
            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }
    
            // Find the existing user by email
            $user = Auth::guard('chauffeur')->user();
    
            if (!$user) {
                return response()->json(['error' => 'User not found!'], 404);
            }
    
            // Update user data
            $user->update([
                'fname'    => $request->fname,
                'lname'    => $request->lname,
                'phone'    => $request->phone,
                'password' => $request->password ? bcrypt($request->password) : $user->password,
            ]);
    
            return response()->json([
                'message'  => 'User updated successfully!',
                'user'     => $user
            ], 200);
    
        } catch (\Exception $e) {
            return response()->json(['error' => 'Something went wrong!', 'details' => $e->getMessage()], 500);
        }
    }


    public function storeVehicle(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'vehicle_model'  => 'required|string|max:255',
                'vehicle_year'   => 'required|numeric|min:1900|max:'.(date('Y')+1),
                'vehicle_color'  => 'required|string|max:255',
                'vehicle_type'   => 'required|string|in:SUV,Sedan,Stretch,Sprinter',
                'plate' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'errors' => $validator->errors()
                ], 422);
            }

            $chauffeur = Auth::guard('chauffeur')->user();

            $vehicle = $chauffeur->vehicledetails()->updateOrCreate(
               ['chauffers_id' => $chauffeur->id],
               [
                   'model'  => $request->vehicle_model,
                   'year'   => $request->vehicle_year,
                   'color'  => $request->vehicle_color,
                   'service' => $request->vehicle_type,
                   'plate'   => $request->plate,
               ]
            );

            return response()->json([
                'message' => 'Vehicle details saved successfully!',
                'data' => $vehicle
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Server error: '.$e->getMessage()
            ], 500);
        }
    }

}
